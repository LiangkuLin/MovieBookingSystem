package com.example.demo;

import java.util.Date;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.model.Cinema;
import com.example.demo.model.CinemaRepository;
import com.example.demo.model.Movie;
import com.example.demo.model.MovieRepository;
import com.example.demo.model.Reservation;
import com.example.demo.model.ReservationRepository;
import com.example.demo.model.Screen;
import com.example.demo.model.ScreenRpository;
import com.example.demo.model.Seat;
import com.example.demo.model.SeatRepository;
import com.example.demo.model.Show;
import com.example.demo.model.ShowRepository;
import com.example.demo.model.User;
import com.example.demo.model.UserRepository;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	ApplicationRunner init(ReservationRepository reservationRepository, UserRepository userRepository,
			CinemaRepository cinemaRepository, ScreenRpository screenRepository, ShowRepository showRepository,
			MovieRepository movieRepository, SeatRepository seatRepository) {
		return args -> {

			Cinema[] cinemas = { new Cinema("Central Theatre", "New Westminster"),
					new Cinema("Royal Cinema", "Burnaby"), new Cinema("Vancouver Theatre", "Vancouver") };

			Screen[] screens = { new Screen("Screen A", 60), new Screen("Screen B", 50), new Screen("Screen C", 70),
					new Screen("Screen D", 40), new Screen("Screen F", 80) };

			Seat[] seats = { new Seat(1, 01, 01, true, 19), new Seat(2, 01, 02, true, 19),
					new Seat(3, 01, 03, true, 19) };

			Show[] shows = { new Show("12-2-2022", "12:00:00", "15:00:00"),
					new Show("12-2-2022", "16:00:00", "19:00:00"), new Show("12-2-2022", "19:30:00", "22:00:00") };

			Date dateForNow = new Date();

			Movie[] movies = { new Movie("Movie 1", "description1", 300, "category1", dateForNow),
					new Movie("Movie 2", "description1", 600, "category2", dateForNow) };

			User[] userList = { new User("Jack", "A123456", "7783222333", "address1", "Jack@gmail"),
					new User("An", "B123456", "7783232335", "address2", "An@gmail") };
			Reservation[] reservations = { new Reservation(), new Reservation(), new Reservation() };

			// add show to screen
			screens[0].addShows(shows[0]);
			screens[1].addShows(shows[1]);
			screens[2].addShows(shows[2]);
			
//			movies[0].addShow(shows[0]);
//			movies[1].addShow(shows[1]);
//			movies[1].addShow(shows[2]);

			shows[0].addSeats(seats[0]);
			shows[1].addSeats(seats[1]);
			shows[2].addSeats(seats[2]);
			
//			reservations[0].addSeats(seats[0]);
//			reservations[1].addSeats(seats[1]);
//			reservations[2].addSeats(seats[2]);

			userList[0].addOneReservation(reservations[0]);
			userList[1].addOneReservation(reservations[1]);
			userList[1].addOneReservation(reservations[2]);

			// add screens into cinemas
			cinemas[0].addScreen(screens[0]);
			cinemas[0].addScreen(screens[1]);
			cinemas[0].addScreen(screens[2]);
			cinemas[1].addScreen(screens[3]);
			cinemas[1].addScreen(screens[4]);

			for (int i = 0; i < cinemas.length; i++) {
				cinemaRepository.save(cinemas[i]);
			}

			for (int i = 0; i < seats.length; i++) {
				seatRepository.save(seats[i]);
			}

			for (int i = 0; i < movies.length; i++) {

				movieRepository.save(movies[i]);
			}

			for (int i = 0; i < shows.length; i++) {
				showRepository.save(shows[i]);
			}

			for (int i = 0; i < screens.length; i++) {
				screenRepository.save(screens[i]);
			}

			for (int i = 0; i < userList.length; i++) {
				userRepository.save(userList[i]);
			}

			// print info for debug
			cinemaRepository.findAll().forEach(System.out::println);
			movieRepository.findAll().forEach(System.out::println);

		};

	}

}
